This is a paint simple application.

Used tkinter and python.